import pandas as pd


def asin_creator(df_copy):
    df1=df_copy["Asin"]
    df1=pd.DataFrame(df1)
    return df1
