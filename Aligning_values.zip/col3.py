import pandas as pd
import re


class failure_reasons:
    def __init__(self, df_copy):
        self.df_copy = df_copy
        self.df = df_copy

    def create_dataframe(self):
        regex_pattern = r'RASTER_DIFF_FAIL|RESOURCE_IMAGE_DIFF_FAIL|FPID_RETRIEVAL_FAIL|FP_VALIDATION_FAILURE'
        data = {}
        for col in self.df.columns:
            if self.df[col].dtype != 'object':
                self.df[col] = self.df[col].astype(str)
            values = self.df[col].apply(lambda x: re.findall(regex_pattern, x) if isinstance(x, str) else None).tolist()
            data[col] = [v[0] if v else None for v in values]  # Print None if no match found
        self.df_new = pd.DataFrame(data)

    def concatenate_columns(self):
        # create a new column with empty string
        self.df_new['FAILURES'] = ''

        # iterate over each row
        for index, row in self.df_new.iterrows():
            # concatenate all non-null values across five columns
            values = [str(row[col]) for col in ['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'] if
                      not pd.isna(row[col])]
            concatenated = ','.join(values)
            self.df_new.at[index, 'FAILURES'] = concatenated
        self.df_new.drop(columns=['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'], inplace=True)
        return self.df_new