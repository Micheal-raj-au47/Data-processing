import pandas as pd
import re

class revision_generator:
    def __init__(self, df_copy):
        self.df_copy = df_copy
        self.df = df_copy

    def create_dataframe(self):
        regex_pattern = r'^[a-z0-9]+$|\d{6,9}'
        data = {}
        for col in self.df.columns:
            if self.df[col].dtype != 'object':
                self.df[col] = self.df[col].astype(str)
            values = self.df[col].apply(lambda x: re.findall(regex_pattern, x) if isinstance(x, str) else None).tolist()
            data[col] = [v[0] if v else None for v in values]  # Print None if no match found
        self.revis = pd.DataFrame(data)

    def concatenate_columns(self):
        # create a new column with empty string
        self.revis['REVISIONS'] = ''

        # iterate over each row
        for index, row in self.revis.iterrows():
            # concatenate all non-null values across six columns
            values = [str(row[col]) for col in ['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'] if
                      not pd.isna(row[col])]
            if values:  # Only concatenate non-empty lists
                concatenated = ','.join(values)
                self.revis.at[index, 'REVISIONS'] = concatenated
            else:  # Remove rows with empty lists
                self.revis.drop(index, inplace=True)

        # Remove original columns
        self.revis.drop(columns=['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'], inplace=True)

        return self.revis
