from Facet import DataFrameManipulator
from revision import revision_generator
from failure import failure_reasons
from Asin import asin_creator
import pandas as pd


filename = input("Enter the path to your CSV file: ")

def create_dataframe_from_csv():
    df = pd.read_csv(filename, usecols=range(9, 15))
    df.rename(columns={"tag 1": "Asin", "tag 2": "revision", "tag 3": "Failure1", "tag 4": "Failure2",
                       "tag 5": "Facets", "Unnamed: 14": "facets2"}, inplace=True)
    df_copy = df.copy()
    return df_copy

def main():
    df_copy = create_dataframe_from_csv()
    manipulator = DataFrameManipulator(df_copy)
    facet = manipulator.create_dataframe()
    facet = manipulator.concatenate_Facets()
    revisioner=revision_generator(df_copy)
    revis = revisioner.create_dataframe()
    revis = revisioner.concatenate_columns()
    failurer=failure_reasons(df_copy)
    df_new = failurer.create_dataframe()
    df_new = failurer.concatenate_columns()
    df1=asin_creator(df_copy)
    #df1 = Asins.create_dataframe()
    df_concat = pd.concat([df1,revis,facet,df_new], axis=1)
    df_concat.to_csv('file.csv', sep=',', index=False)


if __name__ == '__main__':
    main()
    #print(df_concat)
