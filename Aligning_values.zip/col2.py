import pandas as pd
import re


class DataFrameManipulator:
    def __init__(self, df_copy):
        self.df_copy = df_copy
        self.df = df_copy

    def create_dataframe(self):
        regex_pattern = r'YJBINARY_(HD_KIR1|HD|JPEGXR_SD_KIR1|JPEGXR_SD|YJBASELINE1_HD|YJBASELINE1_SD)'
        data = {}
        for col in self.df.columns:
            if self.df[col].dtype != 'object':
                self.df[col] = self.df[col].astype(str)
            values = self.df[col].apply(lambda x: re.findall(regex_pattern, x) if isinstance(x, str) else None).tolist()
            data[col] = [v[0] if v else None for v in values]  # Print None if no match found
        self.facet = pd.DataFrame(data)

    def concatenate_Facets(self):
        # create a new column with empty string
        self.facet['FACETS'] = ''

        # iterate over each row
        for index, row in self.facet.iterrows():
            # concatenate all non-null values across five columns
            values = [str(row[col]) for col in ['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'] if
                      not pd.isna(row[col])]
            FACETS = ','.join(values)
            self.facet.at[index, 'FACETS'] = FACETS
        self.facet.drop(columns=['Asin', 'revision', 'Failure1', 'Failure2', 'Facets', 'facets2'], inplace=True)
        return self.facet